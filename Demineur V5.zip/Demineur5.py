from ressource import *
from tkinter import *

s = int(input("Choisissez un niveau (0/1/2)"))

root=Tk()
niveau=[[9,15,70],[15,30,43],[20,66,32]]
t = niveau[s][2]
x = niveau[s][0]

can = Canvas(root, width=x*t,height=x*t, bg="white")
can.pack(side="bottom")

lbl = Label(root,text="",font=("arial",16,"italic"))
lbl.pack()

bmbCmpt = Label(root,text="Nombre de bombe : "+str(niveau[s][1]),font=("arial",16,"italic"))
bmbCmpt.pack(side=LEFT)

rst = Button(root,text="Reset",font=("arial",16,"italic"),command= lambda :reset(can,lbl,bmbCmpt))
rst.pack(anchor="ne",padx=25)


Jeu(can,lbl,bmbCmpt,rst,root,s)



mainloop()