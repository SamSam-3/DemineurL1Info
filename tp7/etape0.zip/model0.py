from random import randrange

NB_SQUARES=4

def shuffle_board(n=NB_SQUARES, N=100):
    # Renvoie un plateau bien mélangé
    # N : Nombre de mélanges

    def echange(board, empty):
        i, j=empty
        V=[(a,b) for (a, b) in
                [(i, j+1),(i, j-1), (i-1, j), (i+1,j)]
                if a in range(n) and b in range(n)]    
        ii, jj=V[randrange(len(V))]
        board[ii][jj], board[i][j]=board[i][j],board[ii][jj]
        return ii, jj
    
    board=[[n*lin+col+1 for col in range(n)]
        for lin in range(n)]
    board[n-1][n-1]=0
    empty=(n-1,n-1)

    for i in range(N):
        empty=echange(board, empty)
        
    return board


def print_board(board):
    print('\n'.join([' '.join(["%2s"%v for v in L ]) for L in board]))
    
    


