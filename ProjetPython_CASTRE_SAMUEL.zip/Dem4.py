from biblio import *
from random import *
from tkinter import *
import time

# - Mettre toutes les fonctions dans un fichier .py
# - Niveau Chrono/CS/Bombe mouvante/Mode duel 

##Creation du plateau de jeuù
global win
win=0
r = matriceNulle(10,10)
n,p = dimensions(r)
w=0
root = Tk()
root.title("Démineur")

img=[]
Ind=[]
bomb=[]
draps=[]
interro=[]
interr=[]
dp=[]

nbrBomb,nbfix = 15,15
tot=n*p
global pkpas
pkpas=time.time()

for q in range(n):
    for d in range(p):
        dp.append("")
        interr.append("")
 
#Reset le plateau de jeu
def reset():
    can.delete("all")
    global tot
    global w
    global nbrBomb
    global win
    pkpas=time.time()
    win=0
    nbrBomb=15
    bmbCmpt['text']=str(15)
    w=0
    tot=n*p
    draps.clear()
    Ind.clear()
    lbl.config(text="")
    for i in range(n):
        for j in range(p):
            r[i][j]=0
    generePlateau() # Genère le plateau construit | matrice r remplie
    Game() # Aspect graphique
    print()
    afficher(r) # Affiche la matrice
    couverture() # recouvre le plateau

# Plateau de jeu algo
def generePlateau():
    global Ind
    global bomb
    bomb.clear()
    h=0
    while h<nbrBomb:
        h+=1
        x = randint(0,9)
        y = randint(0,9)
    ## Recuperation indices des bombes
        if r[x][y]!="X":
          r[x][y]="X"
          Ind.append([x,y])
          bomb.append((x*10)+y)
        else:
            h-=1

    # Incrementer autour des bombes
    for i in Ind:
        a,b=i[0],i[1]
        s,t=-1,-1
        for i in range(3):
            for j in range(3):
                if(0<=a+s<=n-1 and 0<=b+t<=n-1 and r[a+s][b+t]!="X"):
                    r[a+s][b+t]+=1 # Incrementation autour bombe
                t+=1    
            s+=1
            t=-1         

# Devoile la case cliqué
def devoile(event):
    i,j = int(event.x/70),int(event.y/70)
    t = (j*10)+i
    total=n*p
    global win
    global tot

    if(t in bomb):
        lbl.config(text="T'a perdu FDP !",font=("arial",16,"italic"))
        for h in range(total):
            can.delete(img[h])
        win=1

    else:
        can.delete(img[t])
        tot-=1

    if (tot==nbfix and nbrBomb==0):
        win=1
        lbl.config(text="T'a gagné FDP !"+t ,font=("arial",16,"italic"))
        
    return j,i    

# A refaire
def chrono():
    global win
    t=time.time()-pkpas #Met le timer à 0
    if win==0:
        lbl.config(text=time.strftime("%M:%S", time.localtime(t)),font=("arial",16,"italic"))
    root.after(1000,chrono)

#Libère le plateau des 0 au 1er clique
def Play(event):
    global w
    i,j = devoile(event)
    s,t=-1,-1
    global tot

    if w==0:
        for a in range(n):
            for b in range(p):
                t = (a*10)+b
                if (r[a][b]==0 or r[a][b]==1):
                    can.delete(img[t])
                    tot-=1
                    chrono()
                    w=1       

# Recouvre le plateau pour cacher les indices
def couverture():
    x=0
    y=0
    s=0

    for i in range(n):
        for j in range(p):
            img.append("")
            img[s] = can.create_image(x+35,y+35,image=couv)
            s+=1
            x+=70
        x=0
        y+=70
    return img

# Plateau de jeu graphique
def Game():
    x=0
    y=0

    for i in range(n):
        for j in range(p):
            can.create_rectangle((x,y),(x+70,y+70), fill="gray",outline='black')
            if r[i][j]==1:
                can.create_text((x+35,y+35), text=r[i][j], font=("arial",16,"italic"), fill="white")
            if r[i][j]==2:
                can.create_text((x+35,y+35), text=r[i][j], font=("arial",16,"italic"), fill="blue")
            if r[i][j]==3:
                can.create_text((x+35,y+35), text=r[i][j], font=("arial",16,"italic"), fill="green")
            if r[i][j]==4:
                can.create_text((x+35,y+35), text=r[i][j], font=("arial",16,"italic"), fill="dark violet")
            if r[i][j]==5:
                can.create_text((x+35,y+35), text=r[i][j], font=("arial",16,"italic"), fill="yellow")
            if r[i][j]=="X":
                can.create_image((x+35,y+35),image=bombe)
            x+=70
        x=0
        y+=70

# Pose de drapeau sur le plateau
def drapeaux(event):
    z,r=int(event.x/70),int(event.y/70)
    g=(r*10)+z
    global nbrBomb

    if ([z,r] in draps and [z,r] in interro):
        try:
            
            
            can.delete(dp[g])
            can.delete(interr[g])
           
            draps.remove([z,r])
            interro.remove([z,r])
            dp.remove(g)
            interr.remove(g)
            
        except:
            print("",end="")

    elif not([z,r] in draps):
            draps.append([z,r])
            dp[g] = can.create_image((35+(z*70),35+(r*70)),image=drap)

    elif ([z,r] in draps) and (not([z,r] in interro)):
            interro.append([z,r])
            interr[g] = can.create_image((35+(z*70),35+(r*70)),image=ptInter)


    if ([r,z] in Ind) and (([z,r] in draps) or ([z,r] in interro)):
        nbrBomb-=1
    else:
        nbrBomb+=1
    
    bmbCmpt['text']=str(nbrBomb) 

can = Canvas(root, width=700,height=700, bg="white")
can.pack(side="bottom")
lbl = Label(root,text="",font=("arial",16,"italic"))
lbl.pack()

couv = PhotoImage(file="images/button.png")
drap = PhotoImage(file="images/drapeaux.png")
bombe = PhotoImage(file="images/bombe.png")
ptInter = PhotoImage(file="images/ptInterrogation.png")

bmbCmpt = Label(root,text=nbrBomb,font=("arial",16,"italic"))
bmbCmpt.pack(side=LEFT)

rst = Button(root,text="Reset",font=("arial",16,"italic"),command=reset)
rst.pack(anchor="ne",padx=25)

generePlateau() # Genère le plateau construit | matrice r remplie
Game() # Aspect graphique
afficher(r) # Affiche la matrice
couverture() # recouvre le plateau
#chrono()
root.bind("<Button-1>", Play)
root.bind("<Button-3>", drapeaux)
mainloop()