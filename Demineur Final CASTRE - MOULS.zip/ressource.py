from random import *
from tkinter import *
import time

# - Niveau Chrono/CS/Bombe mouvante/Mode duel 

##Creation du plateau de jeu
win=0

sss=0
c=0
d=0

r = [0]

nbf = 0
nbrBomb =0

pkpas=time.time()
root=""
niveau=[[9,15],[15,30],[20,66]]
taille=0

img=[]
Ind=[]
bomb=[]
draps=[]
interro=[]
interr=[]
dp=[]

timer=""
couv = ""
drap = ""
bombe = ""
ptInter = ""
ldl = ""
bmbCmpt = ""

def afficher(M):
    "Affiche une matrice en respectant les alignements par colonnes"
    w=[max([len(str(M[i][j])) for i in range(len(M))]) for j in range(len(M[0]))]
    for i in range(len(M)):
        for j in range(len(M[0])):
            print("%*s" %(w[j],str(M[i][j])), end= ' ')
        print()        

def matriceNulle(n, p):
    "Constructeur de matrice de dimensions données"
    M=[]
    for i in range(n):
        L=[]
        for j in range(p):
            L.append(0)
        M.append(L)
    return M

def Jeu(can, lbl, labelBomb, rst, Tk, niv):

    global couv
    global drap
    global bombe
    global ptInter
    global ldl
    global bmbCmpt
    global nbf
    global taille
    global root


    root=Tk
    nbf = niveau[niv][1]
    ldl = lbl
    bmbCmpt = labelBomb

    if niv==0:
        couv = PhotoImage(file="images/buttonFacile.png")
        drap = PhotoImage(file="images/drapeauxFacile.png")
        bombe = PhotoImage(file="images/bombeFacile.png")
        ptInter = PhotoImage(file="images/ptInterrogationFacile.png")
        taille=70

    if niv==1:
        couv = PhotoImage(file="images/buttonMoyen.png")
        drap = PhotoImage(file="images/drapeauxMoyen.png")
        bombe = PhotoImage(file="images/bombeMoyen.png")
        ptInter = PhotoImage(file="images/ptInterrogationMoyen.png")
        taille=43

    if niv==2:
        couv = PhotoImage(file="images/buttonDifficile.png")
        drap = PhotoImage(file="images/drapeauxDifficile.png")
        bombe = PhotoImage(file="images/bombeDifficile.png")
        ptInter = PhotoImage(file="images/ptInterrogationDifficile.png")
        taille=32

    global c
    c = coteJeu(niveau[niv][0])

    global d
    d = nbbomb(niveau[niv][1])

    global r
    r = matriceNulle(c,c)

    global nbrBomb
    print(nbrBomb)
    for q in range(c):
        for d in range(c):
            dp.append("")
            interr.append("")

    generePlateau() # Genère le plateau construit | matrice r remplie
    Game(can) # Aspect graphique
    couverture(can) # recouvre le plateau
    afficher(r) # Affiche la matrice

    Tk.bind("<Button-1>", lambda event: Play(event,can))
    Tk.bind("<Button-3>",  lambda event: drapeaux(event,can))

def coteJeu(cte):
    cote=cte

    return cote

def nbbomb(nbb):
    global nbrBomb
    nbrBomb=nbb

    return nbrBomb
 
#Reset le plateau de jeu
def reset(can,lbl,bmbCmpt):
    can.delete("all")
    global win
    global sss
    sss=0

    global pkpas
    pkpas=time.time()

    win=0
    global nbrBomb
    nbrBomb=nbf
    bmbCmpt['text']="Nombre de bombe : "+str(nbrBomb)
    w=0
    tot=c*c
    draps.clear()
    Ind.clear()
    lbl.config(text="")
    for i in range(c):
        for j in range(c):
            r[i][j]=0
            
    generePlateau() # Genère le plateau construit | matrice r remplie
    
    Game(can) # Aspect graphique
    couverture(can) # recouvre le plateau
    print()
    afficher(r) # Affiche la matrice

# Plateau de jeu algo
def generePlateau():

    bomb.clear()
    h=0
    while h<nbrBomb:
        h+=1
        x = randint(0,c-1)
        y = randint(0,c-1)
    ## Recuperation indices des bombes
        if r[x][y]!="X":
          r[x][y]="X"
          Ind.append([x,y])
          bomb.append((x*c)+y)
        else:
            h-=1

    # Incrementer autour des bombes
    for i in Ind:
        a,b=i[0],i[1]
        s,t=-1,-1
        for i in range(3):
            for j in range(3):
                if(0<=a+s<=c-1 and 0<=b+t<=c-1 and r[a+s][b+t]!="X"):
                    r[a+s][b+t]+=1 # Incrementation autour bombe
                t+=1    
            s+=1
            t=-1         

# Devoile la case cliqué
def devoile(event,can):
    i,j = int(event.x/taille),int(event.y/taille)
    t = (j*c)+i
    total = c*c
    global win

    if(t in bomb):
        ldl.config(text="PERDU !  -  "+time.strftime("%M:%S", time.localtime(timer)),font=("arial",16,"italic"))
        for h in range(total):
            can.delete(img[h])
        win=1

    else:
        can.delete(img[t])
        total-=1

    if (nbrBomb==0):
        win=1
        ldl.config(text="BRAVO !  -  "+time.strftime("%M:%S", time.localtime(timer)),font=("arial",16,"italic"))
        
    return j,i    

# A refaire
def chrono():
    global timer
    timer=time.time()-pkpas #Met le timer à 0

    if win==0:
        ldl.config(text=time.strftime("%M:%S", time.localtime(timer)),font=("arial",16,"italic"))
        root.after(1000,lambda :chrono())

#Libère le plateau des 0 au 1er clique
def Play(event, can):
    i,j = devoile(event,can)
    s,t=-1,-1
    total = c*c
    global sss
    temp=0

    if sss==0:
        for a in range(c):
            for b in range(c):
                t = temp+b
                if (r[a][b]==0 or r[a][b]==1):
                    can.delete(img[t])
                    total-=1
            temp+=c
        chrono()
        sss=1
    print(total)

# Recouvre le plateau pour cacher les indices
def couverture(can):
    x=0
    y=0
    s=0
    for i in range(c):
        for j in range(c):
            img.append("")
            img[s] = can.create_image(x+(taille/2),y+(taille/2),image=couv)
            s+=1
            x+=taille
        x=0
        y+=taille
    return img

# Plateau de jeu graphique
def Game(can):
    x=0
    y=0

    for i in range(c):
        for j in range(c):
            can.create_rectangle((x,y),(x+taille,y+taille), fill="gray",outline='black')
            if r[i][j]==1:
                can.create_text(x+(taille/2),y+(taille/2), text=r[i][j], font=("arial",16,"italic"), fill="white")
            if r[i][j]==2:
                can.create_text((x+(taille/2),y+(taille/2)), text=r[i][j], font=("arial",16,"italic"), fill="blue")
            if r[i][j]==3:
                can.create_text((x+(taille/2),y+(taille/2)), text=r[i][j], font=("arial",16,"italic"), fill="green")
            if r[i][j]==4:
                can.create_text((x+(taille/2),y+(taille/2)), text=r[i][j], font=("arial",16,"italic"), fill="dark violet")
            if r[i][j]==5:
                can.create_text((x+(taille/2),y+(taille/2)), text=r[i][j], font=("arial",16,"italic"), fill="yellow")
            if r[i][j]==6:
                can.create_text((x+(taille/2),y+(taille/2)), text=r[i][j], font=("arial",16,"italic"), fill="dark orange")
            if r[i][j]==7:
                can.create_text((x+(taille/2),y+(taille/2)), text=r[i][j], font=("arial",16,"italic"), fill="maroon")
            if r[i][j]==8:
                can.create_text((x+(taille/2),y+(taille/2)), text=r[i][j], font=("arial",16,"italic"), fill="black")
            if r[i][j]=="X":
                can.create_image((x+(taille/2),y+(taille/2)),image=bombe)
            x+=taille
        x=0
        y+=taille

# Pose de drapeau sur le plateau
def drapeaux(event,can):
    z,r=int(event.x/taille),int(event.y/taille)
    g=(r*c)+z
    global nbrBomb

    if ([z,r] in draps and [z,r] in interro):
        try:
            
            
            can.delete(dp[g])
            can.delete(interr[g])
           
            draps.remove([z,r])
            interro.remove([z,r])
            dp.remove(g)
            interr.remove(g)
            
        except:
            print("",end="")

    elif not([z,r] in draps):
            draps.append([z,r])
            dp[g] = can.create_image(((taille/2)+(z*taille),(taille/2)+(r*taille)),image=drap)

    elif ([z,r] in draps) and (not([z,r] in interro)):
            interro.append([z,r])
            interr[g] = can.create_image((taille/2)+(z*taille),(taille/2)+(r*taille),image=ptInter)


    if ([r,z] in Ind) and (([z,r] in draps) or ([z,r] in interro)):
        nbrBomb-=1
    else:
        nbrBomb+=1
    bmbCmpt['text']="Nombre de bombe : "+str(nbrBomb)