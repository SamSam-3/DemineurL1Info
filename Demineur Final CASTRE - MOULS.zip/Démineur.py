from tkinter import *
from ressource import *

master = Tk()
master.title("Démineur")
logo = PhotoImage(file="images/logodemineur.png")


def Niveau(s):
    root=Toplevel()
    niveau=[[9,15,70],[15,30,43],[20,66,32]]

    t = niveau[s][2]
    x = niveau[s][0]

    can = Canvas(root, width=x*t,height=x*t, bg="white")
    can.pack(side="bottom")

    lbl = Label(root,text="",font=("arial",16,"italic"))
    lbl.pack()

    bmbCmpt = Label(root,text="Nombre de bombe : "+str(niveau[s][1]),font=("arial",16,"italic"))
    bmbCmpt.pack(side=LEFT)

    rst = Button(root,text="Reset",font=("arial",16,"italic"),command= lambda :reset(can,lbl,bmbCmpt))
    rst.pack(anchor="ne",padx=25)

    Jeu(can,lbl,bmbCmpt,rst,root,s)
    
    mainloop()

cnv = Canvas(width=300, height=300, bg="white")
cnv.pack()
cnv.create_image(150,150, image=logo)
cnv.create_text((150,40), text="DEMINEUR",font=("Malgun Gothic", 18, "bold underline"))

F = Button(master,text="Facile", font=("arial",16,"italic"),bd=4, width=12, height=1, bg="grey", fg="blue", command=lambda :Niveau(0))
F.pack(pady=5)

M = Button(master,text="Moyen", font=("arial",16,"italic"),bd=4, width=12, height=1, bg="grey", fg="green", command=lambda :Niveau(1))
M.pack(pady=5)

D = Button(master,text="Difficile", font=("arial",16,"italic"),bd=4, width=12, height=1, bg="grey", fg="red", command=lambda :Niveau(2))
D.pack(pady=5)

master.mainloop()

